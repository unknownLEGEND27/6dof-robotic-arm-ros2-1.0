from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import ExecuteProcess

from launch import LaunchDescription
from launch_ros.actions import Node
from launch.substitutions import Command, PathJoinSubstitution
from launch_ros.substitutions import FindPackageShare
from launch_ros.parameter_descriptions import ParameterValue

urdf_file = PathJoinSubstitution([
        FindPackageShare('dof6arm'),
        'urdf',
        'backup.urdf'
    ])

robot_description = ParameterValue(
        Command(['cat ', urdf_file]),
        value_type=str
    )


def generate_launch_description():
    return LaunchDescription([

        ExecuteProcess(
            cmd=['gazebo', '--verbose', '-s', 'libgazebo_ros_factory.so'],
            output='screen'),

        Node(
            package='robot_state_publisher',
            executable='robot_state_publisher',
            parameters=[{'robot_description': robot_description}],
        ),

        Node(
            package='gazebo_ros',
            executable='spawn_entity.py',
            arguments=['-topic', 'robot_description', '-entity', 'arm'],
            output='screen'
        ),
    ])