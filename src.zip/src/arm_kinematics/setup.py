from setuptools import find_packages, setup

package_name = 'arm_kinematics'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='unknownlegend',
    maintainer_email='jenilpatel2711@gmail.com',
    description='TODO: Package description',
    license='TODO: License declaration',
    extras_require={
        'test': [
            'pytest',
        ],
    },
    entry_points={
        'console_scripts': [
            'fk_node = arm_kinematics.fk_node:main',
            'ik_node = arm_kinematics.ik_node:main',
            'home_pose_node = arm_kinematics.home_pose_node:main',
            'pose_gui = arm_kinematics.pose_gui_node:main',
        ],
    },
)
